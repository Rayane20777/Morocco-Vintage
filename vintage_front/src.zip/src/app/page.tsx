"use client"

import  from "components/account-form/account-form.component"

export default function SyntheticV0PageForDeployment() {
  return < />
}