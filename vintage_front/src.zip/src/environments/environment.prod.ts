export const environment = {
  production: true,
  apiUrl: 'http://your-production-api-url/api'
}; 